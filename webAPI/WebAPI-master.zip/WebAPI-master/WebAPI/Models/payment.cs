﻿namespace WebAPI.Models
{
    public class payment
    {
        public int PaymentId { get; set; }
        public string Paymentdate { get; set; }

        public string Paymentamount { get; set; }

        public string PaymentProduct { get; set; }

        public string Customer { get; set; }



    }
}
