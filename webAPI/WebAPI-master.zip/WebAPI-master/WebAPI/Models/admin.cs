﻿namespace WebAPI.Models

{
    public class admin
    {
        public int AdminId { get; set; }
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Contact { get; set; }

        public string Email { get; set; }
        public string AdminPassword { get; set; }
    }
}
