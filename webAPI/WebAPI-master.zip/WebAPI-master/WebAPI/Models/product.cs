﻿namespace WebAPI.Models
{
    public class product
    {

        public int ProductId { get; set; }
        public string ProductName { get; set; }

        public string ProductPrice { get; set; }

        public string ProductCategory { get; set; }
        public string ProductImage { get; set; }
    }
}
