﻿namespace WebAPI.Models
{
    
    public class cart
    {
        public int CartId { get; set; }
        public string CartItems { get; set; }
        public string Quantity { get; set; }

    }
}

